import Image from "next/image";
import Link from "next/link";
import { House } from 'lucide-react';
import { Search } from 'lucide-react';

const CategoryBoX = [
	
	{
	
	}
]
export default function CategoryBox() {
  return (
	<>
		<div>
		
		</div>
		
	</>
  );
}
